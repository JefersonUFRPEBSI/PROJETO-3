import streamlit as st

def main():
    st.title("Página 1")
    st.write("Esta é a Página 1. Você pode adicionar mais conteúdo aqui!")
