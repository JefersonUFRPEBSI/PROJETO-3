import streamlit as st

def main():
    st.title("Página 2")
    st.write("Esta é a Página 2. Sinta-se à vontade para personalizá-la!")
