import streamlit as st

def main():
    st.title("Bem-vindo à Página Inicial!")
    st.write("Essa é a página principal da aplicação.")
    st.write("Use o menu lateral para navegar pelas páginas.")
